 function um(){
document.getElementById("campo").value += 1;
}
 function dois(){
document.getElementById("campo").value += 2;
}
 function tres(){
document.getElementById("campo").value += 3;
}
 function quatro(){
document.getElementById("campo").value += 4;
}
 function cinco(){
document.getElementById("campo").value += 5;
}
 function seis(){
document.getElementById("campo").value += 6;
}
 function sete(){
document.getElementById("campo").value += 7;
}
 function oito(){
document.getElementById("campo").value += 8;
}
 function nove(){
document.getElementById("campo").value += 9;
}
 function zero(){
document.getElementById("campo").value += 0;
}
